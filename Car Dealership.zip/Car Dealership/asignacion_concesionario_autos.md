# Asignación — Base de datos: Concesionario de Autos

**Base de datos:** `car_dealership_schema.sql`
**Tablas disponibles:** `dealers`, `brands`, `models`, `employees`, `cars`, `customers`, `sales`

Antes de comenzar, asegúrate de haber ejecutado el script completo (creación de tablas + inserción de datos) en tu editor SQL (DB Fiddle).

---

### Conceptos cubiertos
`SELECT` · `FROM` · `WHERE` · `ORDER BY` · `GROUP BY` · `TOP` / `LIMIT` · `DISTINCT` · `SUM()` · `AVG()` · `COUNT()` · `INNER JOIN`

> **Nota:** DB Fiddle con PostgreSQL o MySQL no soporta la palabra clave `TOP` (esa es de SQL Server). El equivalente es `LIMIT n`. En los ejercicios donde se pide "TOP", usa `LIMIT`.

---

## Preguntas

1. **(SELECT / FROM)** Muestra toda la información de los concesionarios (`dealers`).

2. **(SELECT / FROM)** Muestra el modelo, la marca (`brand_id`) y la categoría de todos los modelos disponibles.

3. **(DISTINCT)** ¿Cuáles son los distintos colores de autos disponibles en el inventario?

4. **(DISTINCT)** ¿Cuáles son los distintos puestos (`role`) que existen entre los empleados?

5. **(WHERE)** Muestra todos los autos cuyo precio sea mayor a $28,000.

6. **(WHERE)** Muestra todos los autos que se encuentran "Available" (disponibles) en el concesionario con `dealer_id = 1`.

7. **(WHERE + AND)** Muestra todos los empleados que tengan el rol de "Manager" y hayan sido contratados después del 2021-01-01.

8. **(ORDER BY)** Muestra todos los autos ordenados por precio de mayor a menor.

9. **(ORDER BY + LIMIT)** Muestra los 10 autos más caros del inventario (usa `LIMIT` en lugar de `TOP`).

10. **(COUNT)** ¿Cuántos autos hay en total en el inventario de todos los concesionarios?

11. **(COUNT + WHERE)** ¿Cuántos autos han sido vendidos (`status = 'Sold'`)?

12. **(SUM)** ¿Cuál es el valor total (`price`) de todo el inventario de autos disponibles (`status = 'Available'`)?

13. **(AVG)** ¿Cuál es el precio promedio de venta (`sale_price`) registrado en la tabla `sales`?

14. **(GROUP BY + COUNT)** ¿Cuántos autos tiene cada concesionario en su inventario? (agrupa por `dealer_id`)

15. **(GROUP BY + AVG)** ¿Cuál es el precio promedio de los autos por cada modelo? (agrupa por `model_id`)

16. **(GROUP BY + SUM + ORDER BY)** ¿Cuál es el monto total vendido (`sale_price`) por cada empleado? Ordena el resultado de mayor a menor para identificar al vendedor con más ventas.

17. **(INNER JOIN)** Muestra el nombre de cada auto vendido junto con el nombre y apellido del cliente que lo compró (une `sales` con `cars` y `customers`).

18. **(INNER JOIN + GROUP BY + COUNT)** Muestra el nombre de cada concesionario junto con la cantidad de empleados que tiene (une `dealers` con `employees`, agrupa por concesionario).

---

*Instrucciones de entrega: escribe la consulta SQL para cada pregunta y adjunta una captura de pantalla del resultado obtenido en DB Fiddle. Envía un solo documento con las 18 consultas numeradas en el mismo orden que esta guía.*
