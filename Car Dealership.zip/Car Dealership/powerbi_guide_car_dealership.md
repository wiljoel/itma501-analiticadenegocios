# Power BI walkthrough — Car Dealership dashboard

Files needed: `dealers.csv`, `brands.csv`, `models.csv`, `employees.csv`, `cars.csv`, `customers.csv`, `sales.csv`

---

## Step 1 — Import the data
1. Open Power BI Desktop → **Get Data** → **Text/CSV**.
2. Import all 7 CSV files (or use **Get Data → Folder**).
3. Click **Load** for each (rename columns in **Transform Data** only if you want friendlier labels).

## Step 2 — Build the semantic model (relationships)
Go to **Model view** and create these relationships:

| From | To |
|---|---|
| `cars[dealer_id]` | `dealers[dealer_id]` |
| `cars[model_id]` | `models[model_id]` |
| `models[brand_id]` | `brands[brand_id]` |
| `employees[dealer_id]` | `dealers[dealer_id]` |
| `sales[car_id]` | `cars[car_id]` |
| `sales[customer_id]` | `customers[customer_id]` |
| `sales[employee_id]` | `employees[employee_id]` |

## Step 3 — Create the measures
Select the `sales` table in the Fields pane → right-click → **New measure**, and add:

```
Total Sales = SUM(sales[sale_price])
```
```
Cars Sold = DISTINCTCOUNT(sales[car_id])
```
```
Avg Sale Price = AVERAGE(sales[sale_price])
```
```
Total Inventory = DISTINCTCOUNT(cars[car_id])
```
```
Available Inventory = CALCULATE([Total Inventory], cars[status] = "Available")
```
```
Sell Through Rate = DIVIDE([Cars Sold], [Total Inventory])
```

## Step 4 — KPI cards
1. Insert 5 **Card** visuals across the top: `Total Sales`, `Cars Sold`, `Total Inventory`, `Avg Sale Price`, `Sell Through Rate`.
2. Format `Sell Through Rate` as a percentage (Format pane → Data format → Percentage).

## Step 5 — Sales by dealer (bar chart)
1. Insert a **Clustered Bar Chart**.
2. Y-axis: `dealers[dealer_name]`
3. Values: `Total Sales`
4. Sort descending.

## Step 6 — Inventory by brand (donut chart)
1. Insert a **Donut Chart**.
2. Legend: `brands[brand_name]`
3. Values: `Total Inventory`

## Step 7 — Top sellers (column chart)
1. Insert a **Clustered Column Chart**.
2. X-axis: `employees[first_name]` (filter `role = "Seller"` using a visual-level filter).
3. Y-axis: `Total Sales`.
4. Sort descending — this is your "who sold the most" leaderboard.

## Step 8 — Available inventory by model (table with Top N)
1. Insert a **Table** visual.
2. Columns: `models[model_name]`, `Available Inventory`, `AVERAGE(cars[price])`.
3. Filter on `model_name` → Top N → 5 → By value = `Available Inventory`.

## Step 9 — Add slicers and finish
1. Insert slicers for: `dealers[dealer_name]`, `brands[brand_name]`, and `cars[status]`.
2. Arrange: KPI cards on top, dealer bar chart + brand donut in the middle row, seller leaderboard and model table below.
3. Click a dealer in the slicer live to show every visual filtering down to that location — a natural way to demo how a regional manager would use this report.

**Talking point for class:** the seller leaderboard chart is the same idea as the `GROUP BY employee_id` + `SUM(sale_price)` question from the lab — point that out explicitly to connect the SQL lesson to the BI tool.
