# Power BI walkthrough — Online Store dashboard

Files needed: `categories.csv`, `products.csv`, `customers_store.csv`, `orders.csv`, `order_items.csv`, `reviews.csv`

---

## Step 1 — Import the data
1. Open Power BI Desktop → **Get Data** → **Text/CSV**.
2. Import all 6 CSV files one at a time (or use **Get Data → Folder** if they're all in one directory).
3. In each import preview, click **Transform Data** if you want to rename columns (optional) — otherwise click **Load**.

## Step 2 — Build the semantic model (relationships)
Go to **Model view** (left sidebar) and drag to create these relationships (all should auto-detect as one-to-many, single direction):

| From | To |
|---|---|
| `products[category_id]` | `categories[category_id]` |
| `orders[customer_id]` | `customers_store[customer_id]` |
| `order_items[order_id]` | `orders[order_id]` |
| `order_items[product_id]` | `products[product_id]` |
| `reviews[product_id]` | `products[product_id]` |
| `reviews[customer_id]` | `customers_store[customer_id]` |

If any relationship doesn't auto-create, drag the field from one table onto the matching field in the other.

## Step 3 — Create the measures
Go to **Report view**, select the `order_items` table in the Fields pane, right-click → **New measure**, and add each of these one at a time:

```
Total Revenue = SUMX(order_items, order_items[quantity] * order_items[unit_price])
```
```
Total Orders = DISTINCTCOUNT(orders[order_id])
```
```
Avg Order Value = DIVIDE([Total Revenue], [Total Orders])
```
```
Avg Rating = AVERAGE(reviews[rating])
```
```
Cancelled Rate = DIVIDE(CALCULATE(COUNTROWS(orders), orders[status] = "Cancelled"), [Total Orders])
```

## Step 4 — KPI cards
1. Insert 4–5 **Card** visuals across the top of the report.
2. Drag one measure into each: `Total Revenue`, `Total Orders`, `Avg Order Value`, `Avg Rating`, and `customers_store[customer_id]` (set to Count Distinct) for "Total Customers".
3. Format each card's font size to ~28pt for readability from the projector.

## Step 5 — Revenue by category (bar chart)
1. Insert a **Clustered Bar Chart**.
2. Y-axis: `categories[category_name]`
3. X-axis (Values): `Total Revenue`
4. Sort descending (click the "..." on the visual → Sort by Total Revenue).

## Step 6 — Orders over time (column chart with drill-down)
1. Insert a **Clustered Column Chart**.
2. X-axis: `orders[order_date]` — Power BI auto-creates a date hierarchy (Year → Quarter → Month → Day).
3. Y-axis: `Total Orders`.
4. Demo tip: click the small drill-down arrows in the visual header to show Year → Month live.

## Step 7 — Top-selling products (table with Top N filter)
1. Insert a **Table** visual.
2. Columns: `products[product_name]`, `SUM(order_items[quantity])`, `Total Revenue`.
3. Click the filter icon on the visual → add a filter on `product_name` → filter type **Top N** → 5 → By value = `Total Revenue`.
4. Sort the table by Total Revenue descending.

## Step 8 — Orders by status (donut chart)
1. Insert a **Donut Chart**.
2. Legend: `orders[status]`
3. Values: `Total Orders`

## Step 9 — Customers by country (map)
1. Insert a **Map** or **Filled Map** visual.
2. Location: `customers_store[country]`
3. Size/Legend: Count of `customer_id`.

## Step 10 — Add slicers and finish
1. Insert 2–3 **Slicer** visuals: one for `categories[category_name]`, one for `orders[status]`, and a date range slicer on `orders[order_date]`.
2. Arrange everything on one page — cards on top, bar chart + donut in the middle row, column chart and table below, map to the side.
3. Click a slicer value live to demonstrate cross-filtering across every visual.

**Talking point for class:** point at the bar chart and say "this is your `GROUP BY category_id` query from this morning's lab — Power BI just does it visually and lets you click to filter everything else."
