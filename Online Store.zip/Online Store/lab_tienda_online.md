# Lab interactivo — Base de datos: Tienda Online

**Base de datos:** `online_store_schema.sql`
**Tablas disponibles:** `categories`, `products`, `customers`, `orders`, `order_items`, `reviews`

Antes de comenzar, asegúrate de haber ejecutado el script completo (creación de tablas + inserción de datos) en tu editor SQL (DB Fiddle).

---

### Conceptos cubiertos
`SELECT` · `FROM` · `WHERE` · `ORDER BY` · `GROUP BY` · `TOP` / `LIMIT` · `DISTINCT` · `SUM()` · `AVG()` · `COUNT()` · `INNER JOIN`

> **Nota:** DB Fiddle con PostgreSQL o MySQL no soporta la palabra clave `TOP` (esa es de SQL Server). El equivalente es `LIMIT n`. En los ejercicios donde se pide "TOP", usa `LIMIT`.

---

## Preguntas

1. **(SELECT / FROM)** Muestra todos los productos junto con su precio y la cantidad disponible en inventario (`stock_quantity`).

2. **(SELECT / FROM)** Muestra el nombre, correo electrónico y país de todos los clientes.

3. **(DISTINCT)** ¿Cuáles son los distintos países en los que viven los clientes? (sin repetir países)

4. **(DISTINCT)** ¿Cuáles son los distintos estados (`status`) que puede tener una orden?

5. **(WHERE)** Muestra todos los productos cuyo precio sea mayor a $50.

6. **(WHERE)** Muestra todos los clientes que viven en "Puerto Rico".

7. **(WHERE + comparación de fechas)** Muestra todas las órdenes realizadas después del 1 de abril de 2024.

8. **(ORDER BY)** Muestra todos los productos ordenados de mayor a menor precio.

9. **(ORDER BY + LIMIT)** Muestra los 5 productos más caros de la tienda (usa `LIMIT` en lugar de `TOP`).

10. **(COUNT)** ¿Cuántos clientes hay registrados en total?

11. **(COUNT + WHERE)** ¿Cuántas órdenes tienen el estado "Cancelled"?

12. **(SUM)** ¿Cuál es la suma total del inventario (`stock_quantity`) de todos los productos?

13. **(AVG)** ¿Cuál es el precio promedio de todos los productos?

14. **(GROUP BY + COUNT)** ¿Cuántos productos hay por cada categoría? (agrupa por `category_id`)

15. **(GROUP BY + AVG)** ¿Cuál es la calificación (`rating`) promedio que ha recibido cada producto según sus reseñas? (agrupa por `product_id` en la tabla `reviews`)

16. **(GROUP BY + SUM + ORDER BY)** ¿Cuál es el monto total vendido (`quantity * unit_price`) por cada orden? Ordena el resultado de mayor a menor.

17. **(INNER JOIN)** Muestra el nombre de cada producto junto con el nombre de su categoría (une `products` con `categories`).

18. **(INNER JOIN + GROUP BY + COUNT)** Muestra el nombre de cada cliente junto con la cantidad total de órdenes que ha realizado (une `customers` con `orders`, agrupa por cliente).

---

*Sugerencia para la clase interactiva: resuelve las preguntas 1–13 en vivo con los estudiantes turnándose para proponer la consulta; deja las preguntas 14–18 (GROUP BY y JOIN) como cierre guiado, ya que son las más avanzadas.*
