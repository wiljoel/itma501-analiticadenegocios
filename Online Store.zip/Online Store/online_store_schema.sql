-- =========================================================
-- ONLINE STORE SAMPLE DATABASE
-- For use in DB Fiddle (or any PostgreSQL/MySQL-compatible sandbox)
-- Designed for: SELECT, FROM, WHERE, GROUP BY, ORDER BY, functions
-- =========================================================

-- ---------- SCHEMA ----------

CREATE TABLE categories (
    category_id   INTEGER PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL
);

CREATE TABLE products (
    product_id      INTEGER PRIMARY KEY,
    product_name    VARCHAR(100) NOT NULL,
    category_id     INTEGER REFERENCES categories(category_id),
    price           DECIMAL(10,2) NOT NULL,
    stock_quantity  INTEGER NOT NULL
);

CREATE TABLE customers (
    customer_id  INTEGER PRIMARY KEY,
    first_name   VARCHAR(50) NOT NULL,
    last_name    VARCHAR(50) NOT NULL,
    email        VARCHAR(100),
    country      VARCHAR(50),
    signup_date  DATE
);

CREATE TABLE orders (
    order_id     INTEGER PRIMARY KEY,
    customer_id  INTEGER REFERENCES customers(customer_id),
    order_date   DATE NOT NULL,
    status       VARCHAR(20) NOT NULL  -- 'Completed', 'Pending', 'Cancelled'
);

CREATE TABLE order_items (
    order_item_id  INTEGER PRIMARY KEY,
    order_id       INTEGER REFERENCES orders(order_id),
    product_id     INTEGER REFERENCES products(product_id),
    quantity       INTEGER NOT NULL,
    unit_price     DECIMAL(10,2) NOT NULL
);

CREATE TABLE reviews (
    review_id    INTEGER PRIMARY KEY,
    product_id   INTEGER REFERENCES products(product_id),
    customer_id  INTEGER REFERENCES customers(customer_id),
    rating       INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    review_date  DATE
);

-- ---------- SAMPLE DATA ----------

INSERT INTO categories (category_id, category_name) VALUES
(1, 'Electronics'),
(2, 'Home & Kitchen'),
(3, 'Sports & Outdoors'),
(4, 'Books'),
(5, 'Toys & Games'),
(6, 'Beauty'),
(7, 'Office Supplies');

INSERT INTO products (product_id, product_name, category_id, price, stock_quantity) VALUES
(1,  'Wireless Mouse',            1, 19.99, 150),
(2,  'Bluetooth Headphones',      1, 49.99, 80),
(3,  '4K Monitor 27"',            1, 229.99, 25),
(4,  'USB-C Charging Cable',      1, 9.99, 300),
(5,  'Smartwatch',                1, 129.99, 60),
(6,  'Non-Stick Frying Pan',      2, 24.99, 90),
(7,  'Electric Kettle',           2, 34.99, 70),
(8,  'Blender',                   2, 44.99, 55),
(9,  'Ceramic Dinner Set',        2, 59.99, 40),
(10, 'Yoga Mat',                  3, 15.99, 200),
(11, 'Adjustable Dumbbell Set',   3, 89.99, 35),
(12, 'Running Shoes',             3, 74.99, 65),
(13, 'Camping Tent (2-person)',   3, 119.99, 20),
(14, 'Mystery Novel Bundle',      4, 22.50, 100),
(15, 'Cookbook: Quick Dinners',   4, 18.00, 120),
(16, 'Children''s Picture Book',  4, 9.50, 150),
(17, 'Board Game: Strategy',      5, 34.99, 45),
(18, 'Building Blocks Set',       5, 29.99, 70),
(19, 'Remote Control Car',        5, 39.99, 50),
(20, 'Facial Moisturizer',        6, 14.99, 130),
(21, 'Shampoo & Conditioner Set', 6, 19.99, 110),
(22, 'Makeup Brush Set',          6, 27.99, 75),
(23, 'Desk Organizer',            7, 12.99, 140),
(24, 'Wireless Keyboard',         7, 39.99, 85),
(25, 'Notebook Pack (5-count)',   7, 8.99, 250);

INSERT INTO customers (customer_id, first_name, last_name, email, country, signup_date) VALUES
(1,  'Ana',      'Rivera',    'ana.rivera@example.com',    'Puerto Rico',   '2024-01-15'),
(2,  'Luis',     'Fernandez', 'luis.f@example.com',        'Puerto Rico',   '2024-02-20'),
(3,  'Maria',    'Santos',    'maria.santos@example.com',  'Dominican Rep', '2024-03-05'),
(4,  'James',    'Carter',    'jcarter@example.com',       'USA',           '2024-01-30'),
(5,  'Emily',    'Nguyen',    'emily.n@example.com',       'USA',           '2024-04-12'),
(6,  'Carlos',   'Diaz',      'carlos.diaz@example.com',   'Mexico',        '2024-02-28'),
(7,  'Sophia',   'Martins',   'sophia.m@example.com',      'Brazil',        '2024-05-01'),
(8,  'Daniel',   'Kim',       'daniel.kim@example.com',    'South Korea',   '2024-03-18'),
(9,  'Olivia',   'Brown',     'olivia.b@example.com',      'Canada',        '2024-06-10'),
(10, 'Pedro',    'Alvarez',   'pedro.a@example.com',       'Puerto Rico',   '2024-01-08'),
(11, 'Grace',    'Lee',       'grace.lee@example.com',     'USA',           '2024-07-22'),
(12, 'Miguel',   'Torres',    'miguel.t@example.com',      'Puerto Rico',   '2024-04-30'),
(13, 'Isabella', 'Rossi',     'isabella.r@example.com',    'Italy',         '2024-05-16'),
(14, 'Noah',     'Wilson',    'noah.w@example.com',        'USA',           '2024-06-25'),
(15, 'Camila',   'Gomez',     'camila.g@example.com',      'Colombia',      '2024-02-11');

INSERT INTO orders (order_id, customer_id, order_date, status) VALUES
(1,  1,  '2024-03-01', 'Completed'),
(2,  2,  '2024-03-03', 'Completed'),
(3,  3,  '2024-03-05', 'Cancelled'),
(4,  1,  '2024-03-10', 'Completed'),
(5,  4,  '2024-03-12', 'Completed'),
(6,  5,  '2024-03-15', 'Pending'),
(7,  6,  '2024-03-18', 'Completed'),
(8,  7,  '2024-03-20', 'Completed'),
(9,  8,  '2024-03-22', 'Completed'),
(10, 2,  '2024-03-25', 'Cancelled'),
(11, 9,  '2024-04-01', 'Completed'),
(12, 10, '2024-04-03', 'Completed'),
(13, 11, '2024-04-05', 'Pending'),
(14, 3,  '2024-04-08', 'Completed'),
(15, 12, '2024-04-10', 'Completed'),
(16, 13, '2024-04-12', 'Completed'),
(17, 4,  '2024-04-15', 'Completed'),
(18, 14, '2024-04-18', 'Cancelled'),
(19, 15, '2024-04-20', 'Completed'),
(20, 6,  '2024-04-22', 'Completed'),
(21, 1,  '2024-05-01', 'Completed'),
(22, 8,  '2024-05-03', 'Pending'),
(23, 9,  '2024-05-05', 'Completed'),
(24, 10, '2024-05-08', 'Completed'),
(25, 5,  '2024-05-10', 'Completed');

INSERT INTO order_items (order_item_id, order_id, product_id, quantity, unit_price) VALUES
(1,  1,  1,  2, 19.99),
(2,  1,  4,  1, 9.99),
(3,  2,  2,  1, 49.99),
(4,  3,  5,  1, 129.99),
(5,  4,  6,  1, 24.99),
(6,  4,  7,  1, 34.99),
(7,  5,  10, 3, 15.99),
(8,  5,  11, 1, 89.99),
(9,  6,  3,  1, 229.99),
(10, 7,  14, 2, 22.50),
(11, 7,  15, 1, 18.00),
(12, 8,  20, 2, 14.99),
(13, 8,  21, 1, 19.99),
(14, 9,  17, 1, 34.99),
(15, 9,  18, 2, 29.99),
(16, 10, 2,  1, 49.99),
(17, 11, 24, 1, 39.99),
(18, 11, 25, 3, 8.99),
(19, 12, 12, 1, 74.99),
(20, 12, 13, 1, 119.99),
(21, 13, 8,  1, 44.99),
(22, 14, 9,  1, 59.99),
(23, 15, 19, 2, 39.99),
(24, 16, 1,  4, 19.99),
(25, 16, 4,  4, 9.99),
(26, 17, 22, 1, 27.99),
(27, 17, 23, 2, 12.99),
(28, 18, 5,  1, 129.99),
(29, 19, 6,  2, 24.99),
(30, 19, 7,  1, 34.99),
(31, 20, 16, 3, 9.50),
(32, 21, 3,  1, 229.99),
(33, 21, 2,  1, 49.99),
(34, 22, 10, 2, 15.99),
(35, 23, 11, 1, 89.99),
(36, 23, 12, 1, 74.99),
(37, 24, 14, 1, 22.50),
(38, 24, 15, 1, 18.00),
(39, 25, 24, 1, 39.99),
(40, 25, 25, 2, 8.99);

INSERT INTO reviews (review_id, product_id, customer_id, rating, review_date) VALUES
(1,  1,  1,  5, '2024-03-05'),
(2,  2,  2,  4, '2024-03-08'),
(3,  5,  4,  3, '2024-03-14'),
(4,  6,  1,  5, '2024-03-15'),
(5,  10, 4,  4, '2024-03-16'),
(6,  3,  5,  2, '2024-03-19'),
(7,  14, 6,  5, '2024-03-22'),
(8,  20, 7,  4, '2024-03-25'),
(9,  17, 8,  5, '2024-03-27'),
(10, 2,  2,  3, '2024-03-30'),
(11, 24, 9,  4, '2024-04-04'),
(12, 12, 10, 5, '2024-04-06'),
(13, 8,  11, 3, '2024-04-08'),
(14, 9,  3,  4, '2024-04-11'),
(15, 19, 12, 5, '2024-04-13'),
(16, 1,  13, 4, '2024-04-16'),
(17, 22, 14, 2, '2024-04-19'),
(18, 5,  15, 5, '2024-04-21'),
(19, 3,  1,  4, '2024-05-02'),
(20, 11, 9,  5, '2024-05-06');
